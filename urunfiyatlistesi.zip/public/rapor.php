<?php
// PDF kayıtlarını oku ve istatistikleri hazırla
$pdf_dir = __DIR__ . '/pdf';
$pdf_files = glob($pdf_dir . '/*.pdf');
$monthly_stats = [];
$bayi_stats = [];

foreach ($pdf_files as $file) {
    // Dosya adından bayi ve tarih çek (ör: bayiadi_atik_alis_1688323200.pdf)
    if (preg_match('/([a-z0-9_]+)_atik_alis_(\d+)\.pdf$/i', basename($file), $m)) {
        $bayi = ucfirst(str_replace('_', ' ', $m[1]));
        $timestamp = (int)$m[2];
        $month = date('Y-m', $timestamp);
        // Aylık toplam
        if (!isset($monthly_stats[$month])) $monthly_stats[$month] = 0;
        $monthly_stats[$month]++;
        // Bayi toplam
        if (!isset($bayi_stats[$bayi])) $bayi_stats[$bayi] = 0;
        $bayi_stats[$bayi]++;
    }
}
ksort($monthly_stats);
arsort($bayi_stats);

?>
<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <title>Atık Akü Raporlama & İstatistik</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .rapor-card {
            max-width: 900px;
            margin: 40px auto;
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 8px 32px #0661aa22;
            padding: 32px;
        }

        h2 {
            color: #0661aa;
        }

        table {
            width: 100%;
            margin: 24px 0;
            border-collapse: collapse;
            background: #f7f9fc;
            border-radius: 10px;
            overflow: hidden;
        }

        th,
        td {
            padding: 12px;
            border: 1px solid #e3e6ed;
            text-align: center;
        }

        th {
            background: linear-gradient(90deg, #0661aa 60%, #2196f3 100%);
            color: #fff;
        }

        tr:nth-child(even) {
            background: #f0f4fa;
        }

        .chart-container {
            width: 100%;
            max-width: 700px;
            margin: 32px auto;
        }
    </style>
</head>

<body>
    <div class="rapor-card">
        <h2>Atık Akü Aylık Raporu</h2>
        <div class="chart-container">
            <canvas id="aylikChart"></canvas>
        </div>
        <table>
            <tr>
                <th>Ay</th>
                <th>Rapor (PDF) Sayısı</th>
            </tr>
            <?php foreach ($monthly_stats as $month => $count): ?>
                <tr>
                    <td><?php echo htmlspecialchars($month); ?></td>
                    <td><?php echo $count; ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
        <h2>Bayi Bazında Rapor</h2>
        <div class="chart-container">
            <canvas id="bayiChart"></canvas>
        </div>
        <table>
            <tr>
                <th>Bayi</th>
                <th>Rapor (PDF) Sayısı</th>
            </tr>
            <?php foreach ($bayi_stats as $bayi => $count): ?>
                <tr>
                    <td><?php echo htmlspecialchars($bayi); ?></td>
                    <td><?php echo $count; ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
        <a href="index.php" style="display:inline-block;margin-top:18px;background:#0661aa;color:#fff;padding:9px 22px;border-radius:7px;font-weight:bold;text-decoration:none;box-shadow:0 2px 8px #e3e9f7;">← Ana Sayfa</a>
        <a href="rapor_bayi_amper.php" style="display:inline-block;margin-top:18px;background:#43a047;color:#fff;padding:9px 22px;border-radius:7px;font-weight:bold;text-decoration:none;box-shadow:0 2px 8px #e3e9f7;margin-left:12px;">Bayi-Amper Detay Raporu</a>
    </div>
    <script>
        // Aylık Chart
        const aylikCtx = document.getElementById('aylikChart').getContext('2d');
        const aylikChart = new Chart(aylikCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_keys($monthly_stats), JSON_UNESCAPED_UNICODE); ?>,
                datasets: [{
                    label: 'Aylık PDF Raporu',
                    data: <?php echo json_encode(array_values($monthly_stats)); ?>,
                    backgroundColor: '#2196f3',
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        stepSize: 1
                    }
                }
            }
        });
        // Bayi Chart
        const bayiCtx = document.getElementById('bayiChart').getContext('2d');
        const bayiChart = new Chart(bayiCtx, {
            type: 'pie',
            data: {
                labels: <?php echo json_encode(array_keys($bayi_stats), JSON_UNESCAPED_UNICODE); ?>,
                datasets: [{
                    label: 'Bayi Bazında PDF',
                    data: <?php echo json_encode(array_values($bayi_stats)); ?>,
                    backgroundColor: [
                        '#0661aa', '#2196f3', '#388e3c', '#fbc02d', '#d32f2f', '#8e24aa', '#ff9800', '#0097a7', '#c2185b', '#43a047'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    </script>


</body>

</html>