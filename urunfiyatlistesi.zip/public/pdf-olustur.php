<?php
require_once __DIR__ . '/../fpdf/fpdf.php';
$urunler = json_decode(file_get_contents(__DIR__ . '/../data/urunler.json'), true);

// Formdan gelen veriler
$musteri = isset($_POST['musteri']) ? trim($_POST['musteri']) : '';
$iskonto = isset($_POST['iskonto']) ? floatval($_POST['iskonto']) : 0;
$adetler = isset($_POST['adet']) ? $_POST['adet'] : [];

// Sipariş edilen ürünleri hazırla
$siparis = [];
$toplam = 0;
foreach ($urunler as $u) {
    $adet = isset($adetler[$u['id']]) ? intval($adetler[$u['id']]) : 0;
    if ($adet > 0) {
        $tutar = $adet * $u['satis_fiyati'];
        $siparis[] = [
            'ad' => $u['ad'],
            'kod' => $u['kod'],
            'tip' => $u['tip'],
            'birim' => $u['birim'],
            'fiyat' => $u['satis_fiyati'],
            'adet' => $adet,
            'tutar' => $tutar
        ];
        $toplam += $tutar;
    }
}
$iskontolu = $toplam * (1 - $iskonto / 100);

$pdf = new FPDF('P', 'mm', 'A4');
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 12, 'Sipariş Özeti', 0, 1, 'C');
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(0, 8, 'Müşteri: ' . $musteri, 0, 1);
$pdf->Cell(0, 8, 'Tarih: ' . date('d.m.Y H:i'), 0, 1);
$pdf->Ln(2);

// Tablo başlıkları
$pdf->SetFont('Arial', 'B', 11);
$pdf->SetFillColor(230, 230, 230);
$pdf->Cell(55, 9, 'Ürün Adı', 1, 0, 'C', true);
$pdf->Cell(25, 9, 'Kod', 1, 0, 'C', true);
$pdf->Cell(20, 9, 'Tip', 1, 0, 'C', true);
$pdf->Cell(15, 9, 'Birim', 1, 0, 'C', true);
$pdf->Cell(20, 9, 'Birim Fiyat', 1, 0, 'C', true);
$pdf->Cell(15, 9, 'Adet', 1, 0, 'C', true);
$pdf->Cell(30, 9, 'Tutar', 1, 1, 'C', true);
$pdf->SetFont('Arial', '', 11);

foreach ($siparis as $s) {
    $pdf->Cell(55, 8, $s['ad'], 1);
    $pdf->Cell(25, 8, $s['kod'], 1);
    $pdf->Cell(20, 8, $s['tip'], 1);
    $pdf->Cell(15, 8, $s['birim'], 1);
    $pdf->Cell(20, 8, number_format($s['fiyat'], 2, ',', '.'), 1, 0, 'R');
    $pdf->Cell(15, 8, $s['adet'], 1, 0, 'C');
    $pdf->Cell(30, 8, number_format($s['tutar'], 2, ',', '.') . ' ₺', 1, 1, 'R');
}
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(150, 10, 'Toplam', 1);
$pdf->Cell(30, 10, number_format($toplam, 2, ',', '.') . ' ₺', 1, 1, 'R');
$pdf->SetFont('Arial', '', 11);
$pdf->Cell(150, 8, 'İskonto (%)', 1);
$pdf->Cell(30, 8, number_format($iskonto, 2, ',', '.') . ' %', 1, 1, 'R');
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(150, 10, 'İskontolu Toplam', 1);
$pdf->Cell(30, 10, number_format($iskontolu, 2, ',', '.') . ' ₺', 1, 1, 'R');
$pdf->Ln(8);
$pdf->SetFont('Arial', 'I', 10);
$pdf->Cell(0, 8, 'Hazırlayan: urunfiyatlistesi', 0, 1, 'R');
$pdf->Output('I', 'siparis-ozeti.pdf');
