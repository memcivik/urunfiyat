<?php
// JSON raporları oku
$raporlar_json = __DIR__ . '/../data/raporlar.json';
$raporlar = file_exists($raporlar_json) ? json_decode(file_get_contents($raporlar_json), true) : [];

// Amper aralığına göre toplamlar
$amper_toplam = [];
// Bayi -> Amper aralığı -> adet
$bayi_amper = [];
foreach ($raporlar as $rapor) {
    $bayi = $rapor['bayi'];
    foreach ($rapor['amperler'] as $aralik => $adet) {
        if (!isset($amper_toplam[$aralik])) $amper_toplam[$aralik] = 0;
        $amper_toplam[$aralik] += $adet;
        if (!isset($bayi_amper[$bayi])) $bayi_amper[$bayi] = [];
        if (!isset($bayi_amper[$bayi][$aralik])) $bayi_amper[$bayi][$aralik] = 0;
        $bayi_amper[$bayi][$aralik] += $adet;
    }
}
uksort($amper_toplam, 'strnatcmp');
ksort($bayi_amper);
// En çok alınan amperler (top 5)
$en_cok_amperler = $amper_toplam;
arsort($en_cok_amperler);
$en_cok_amperler = array_slice($en_cok_amperler, 0, 5, true);
// Toplam adet
$toplam_adet = array_sum($amper_toplam);
?>
<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <title>Bayi-Amper Detaylı Rapor</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background: #f4f7fb;
            font-family: 'Roboto', Arial, sans-serif;
        }

        .kurumsal-header {
            display: flex;
            align-items: center;
            gap: 18px;
            background: #fff;
            border-radius: 0 0 18px 18px;
            box-shadow: 0 4px 24px #0661aa18;
            padding: 18px 32px 18px 18px;
            max-width: 1200px;
            margin: 32px auto 0 auto;
        }

        .kurumsal-header img {
            height: 54px;
            border-radius: 12px;
            background: #f7f9fc;
            box-shadow: 0 2px 8px #0661aa22;
        }

        .kurumsal-header .title {
            font-size: 2em;
            font-weight: 700;
            color: #0661aa;
            letter-spacing: 1px;
        }

        .kurumsal-header .subtitle {
            font-size: 1.1em;
            color: #232a36;
            font-weight: 400;
            margin-top: 2px;
        }

        .rapor-card {
            max-width: 1200px;
            margin: 24px auto 40px auto;
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 8px 32px #0661aa22;
            padding: 32px;
        }

        h2 {
            color: #0661aa;
        }

        table {
            width: 100%;
            margin: 24px 0;
            border-collapse: collapse;
            background: #f7f9fc;
            border-radius: 10px;
            overflow: hidden;
        }

        th,
        td {
            padding: 12px;
            border: 1px solid #e3e6ed;
            text-align: center;
        }

        th {
            background: linear-gradient(90deg, #0661aa 60%, #2196f3 100%);
            color: #fff;
            font-size: 1em;
        }

        tr:nth-child(even) {
            background: #f0f4fa;
        }

        .chart-container {
            width: 100%;
            max-width: 1000px;
            margin: 32px auto;
        }

        .scroll-x {
            overflow-x: auto;
        }

        .dashboard {
            display: flex;
            flex-wrap: wrap;
            gap: 24px;
            justify-content: center;
            margin: 0 0 24px 0;
        }

        .stat-card {
            background: linear-gradient(135deg, #e3e9f7 60%, #fff 100%);
            border-radius: 16px;
            box-shadow: 0 4px 18px #0661aa18;
            padding: 18px 28px;
            min-width: 180px;
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: center;
            transition: box-shadow 0.2s;
        }

        .stat-card:hover {
            box-shadow: 0 8px 32px #2196f344;
            transform: translateY(-2px) scale(1.03);
        }

        .stat-title {
            color: #0661aa;
            font-size: 1em;
            margin-bottom: 8px;
            font-weight: 600;
            letter-spacing: 0.5px;
        }

        .stat-value {
            font-size: 1.5em;
            font-weight: bold;
            color: #232a36;
            margin-bottom: 4px;
        }

        .stat-icon {
            font-size: 1.7em;
            margin-bottom: 8px;
            border-radius: 50%;
            background: #2196f3;
            color: #fff;
            width: 44px;
            height: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 8px auto;
            box-shadow: 0 2px 8px #2196f344;
        }

        .filter-bar {
            margin: 0 0 18px 0;
            text-align: right;
        }

        .filter-bar select {
            padding: 7px 14px;
            border-radius: 7px;
            border: 1px solid #bcd;
            font-size: 1em;
        }

        @media (max-width: 900px) {
            .kurumsal-header {
                flex-direction: column;
                gap: 8px;
                padding: 12px;
            }

            .dashboard {
                flex-direction: column;
                align-items: center;
            }

            .stat-card {
                min-width: 120px;
                padding: 10px 6px;
            }

            .rapor-card {
                padding: 10px;
            }
        }

        footer {
            text-align: center;
            margin: 40px 0 18px 0;
            color: #888;
            font-size: 1em;
            letter-spacing: 0.5px;
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>

<body>
    <div class="kurumsal-header">

        <div>
            <div class="title">Özaydın Oto Elektrik</div>
            <div class="subtitle">Atık Akü Bayi-Amper Detaylı Raporlama</div>
        </div>
    </div>
    <div class="rapor-card">
        <div class="dashboard">
            <div class="stat-card">
                <div class="stat-icon"><i class="fa-solid fa-battery-full"></i></div>
                <div class="stat-title">Toplam Alım</div>
                <div class="stat-value"><?php echo $toplam_adet; ?> Adet</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background:#d32f2f;"><i class="fa-solid fa-bolt"></i></div>
                <div class="stat-title">En Çok Alınan Amperler</div>
                <div class="stat-value" style="font-size:1em;line-height:1.5em;"><?php foreach ($en_cok_amperler as $aralik => $adet) echo htmlspecialchars($aralik) . ": <b>$adet</b><br>"; ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background:#43a047;"><i class="fa-solid fa-users"></i></div>
                <div class="stat-title">Bayi Sayısı</div>
                <div class="stat-value"><?php echo count($bayi_amper); ?></div>
            </div>
        </div>
        <div class="filter-bar">
            <form method="get" id="bayiFilterForm">
                <label for="bayiSelect">Bayi Seç:</label>
                <select name="bayi" id="bayiSelect" onchange="document.getElementById('bayiFilterForm').submit();">
                    <option value="">Tümü</option>
                    <?php foreach (array_keys($bayi_amper) as $bayi): ?>
                        <option value="<?php echo htmlspecialchars($bayi); ?>" <?php if (isset($_GET['bayi']) && $_GET['bayi'] == $bayi) echo 'selected'; ?>><?php echo htmlspecialchars($bayi); ?></option>
                    <?php endforeach; ?>
                </select>
            </form>
        </div>
        <h2>Bayi Bazlı Amper Detay Raporu</h2>
        <div class="scroll-x">
            <table>
                <tr>
                    <th>Bayi</th>
                    <?php foreach (array_keys($amper_toplam) as $aralik): ?>
                        <th><?php echo htmlspecialchars($aralik); ?></th>
                    <?php endforeach; ?>
                </tr>
                <?php foreach ($bayi_amper as $bayi => $araliklar): ?>
                    <?php if (isset($_GET['bayi']) && $_GET['bayi'] !== '' && $_GET['bayi'] != $bayi) continue; ?>
                    <tr>
                        <td><?php echo htmlspecialchars($bayi); ?></td>
                        <?php foreach (array_keys($amper_toplam) as $aralik): ?>
                            <td><?php echo isset($araliklar[$aralik]) ? $araliklar[$aralik] : 0; ?></td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
        <div class="chart-container">
            <canvas id="bayiAmperChart"></canvas>
        </div>
        <a href="rapor.php" style="display:inline-block;margin-top:18px;background:#0661aa;color:#fff;padding:9px 22px;border-radius:7px;font-weight:bold;text-decoration:none;box-shadow:0 2px 8px #e3e9f7;">← Raporlar</a>
    </div>
    <footer>
        © 2024 Baver Soft Web Yazılım Hizmetleri
    </footer>
    <script>
        // Bayi & amper stacked bar chart
        const bayiAmperCtx = document.getElementById('bayiAmperChart').getContext('2d');
        const bayiLabels = <?php
                            if (isset($_GET['bayi']) && $_GET['bayi'] !== '') {
                                echo json_encode([$_GET['bayi']], JSON_UNESCAPED_UNICODE);
                            } else {
                                echo json_encode(array_keys($bayi_amper), JSON_UNESCAPED_UNICODE);
                            }
                            ?>;
        const amperLabels = <?php echo json_encode(array_keys($amper_toplam), JSON_UNESCAPED_UNICODE); ?>;
        const bayiAmperData = <?php echo json_encode($bayi_amper, JSON_UNESCAPED_UNICODE); ?>;
        const bayiDatasets = amperLabels.map((aralik, i) => ({
            label: aralik,
            data: bayiLabels.map(bayi => bayiAmperData[bayi]?.[aralik] ?? 0),
            backgroundColor: [
                '#0661aa', '#2196f3', '#388e3c', '#fbc02d', '#d32f2f', '#8e24aa', '#ff9800', '#0097a7', '#c2185b', '#43a047',
                '#6d4c41', '#00bcd4', '#e91e63', '#607d8b', '#ffd600', '#00e676', '#ff1744', '#aa00ff', '#00bfae', '#ff6f00'
            ][i % 20],
            borderColor: '#fff',
            borderWidth: 1
        }));
        const bayiAmperChart = new Chart(bayiAmperCtx, {
            type: 'bar',
            data: {
                labels: bayiLabels,
                datasets: bayiDatasets
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false
                    }
                },
                scales: {
                    x: {
                        stacked: true
                    },
                    y: {
                        stacked: true,
                        beginAtZero: true,
                        stepSize: 1
                    }
                }
            }
        });
    </script>
</body>

</html>