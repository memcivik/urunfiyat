<?php
header('Content-Type: application/json; charset=utf-8');
$dosya = __DIR__ . '/../data/urunler.json';
$urunler = file_exists($dosya) ? json_decode(file_get_contents($dosya), true) : [];

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        echo json_encode($urunler, JSON_UNESCAPED_UNICODE);
        break;
    case 'POST':
        $input = json_decode(file_get_contents('php://input'), true);
        if (!$input || !isset($input['ad'], $input['kod'], $input['tip'], $input['birim'], $input['satis_fiyati'], $input['kdvsiz_fiyat'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Eksik veri']);
            exit;
        }
        $id = count($urunler) ? max(array_column($urunler, 'id')) + 1 : 1;
        $yeni = [
            'id' => $id,
            'ad' => $input['ad'],
            'kod' => $input['kod'],
            'tip' => $input['tip'],
            'birim' => $input['birim'],
            'satis_fiyati' => floatval($input['satis_fiyati']),
            'kdvsiz_fiyat' => floatval($input['kdvsiz_fiyat'])
        ];
        $urunler[] = $yeni;
        file_put_contents($dosya, json_encode($urunler, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        echo json_encode($yeni, JSON_UNESCAPED_UNICODE);
        break;
    case 'DELETE':
        parse_str(file_get_contents('php://input'), $del);
        if (!isset($del['id'])) {
            http_response_code(400);
            echo json_encode(['error' => 'ID gerekli']);
            exit;
        }
        $urunler = array_values(array_filter($urunler, function ($u) use ($del) {
            return $u['id'] != $del['id'];
        }));
        file_put_contents($dosya, json_encode($urunler, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        echo json_encode(['success' => true]);
        break;
    default:
        http_response_code(405);
        echo json_encode(['error' => 'Yöntem desteklenmiyor']);
}
