<?php
?>
<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ürün Sipariş ve PDF</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            background: #f4f6fb;
        }

        .urun-kart {
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 2px 12px #0001;
            margin-bottom: 24px;
            padding: 18px 18px 10px 18px;
            position: relative;
            transition: box-shadow .2s;
        }

        .urun-kart:hover {
            box-shadow: 0 4px 24px #0002;
        }

        .qty-btn {
            width: 32px;
            height: 32px;
            font-size: 1.2em;
        }

        .qty-input {
            width: 60px;
            text-align: center;
            border-radius: 8px;
            border: 1px solid #ddd;
            margin: 0 6px;
        }

        .urun-isim {
            font-weight: bold;
            font-size: 1.1em;
        }

        .urun-tip {
            font-size: .95em;
            color: #888;
        }

        .urun-fiyat {
            font-size: 1.1em;
            color: #0661aa;
            font-weight: bold;
        }

        .siparis-toplam {
            font-size: 1.2em;
            font-weight: bold;
            color: #0661aa;
        }

        .siparis-iskonto {
            font-size: 1.1em;
            color: #27ae60;
        }

        @media (max-width: 700px) {
            .urun-kart {
                padding: 12px 8px 8px 12px;
            }

            .qty-btn {
                width: 28px;
                height: 28px;
                font-size: 1em;
            }

            .qty-input {
                width: 38px;
            }
        }
    </style>
</head>

<body>
    <div class="container py-4">
        <h1 class="mb-4 text-center">Sipariş Oluştur ve PDF Al</h1>
        <form id="siparisForm" method="post" action="pdf-olustur.php" target="_blank">
            <div class="row mb-4">
                <div class="col-md-6 mx-auto">
                    <div class="card p-3 shadow-sm mb-3">
                        <label for="musteri" class="form-label">Müşteri Adı</label>
                        <input type="text" class="form-control" id="musteri" name="musteri" required>
                    </div>
                    <div class="card p-3 shadow-sm mb-3">
                        <label for="iskonto" class="form-label">Ek İskonto (%)</label>
                        <input type="number" class="form-control" id="iskonto" name="iskonto" min="0" max="100" value="0">
                    </div>
                </div>
            </div>
            <div class="row" id="urunlerAlani"></div>
            <div class="row justify-content-center mt-4">
                <div class="col-lg-6">
                    <div class="card p-3 shadow-sm">
                        <div class="siparis-toplam">Toplam: <span id="toplamTutar">0,00 ₺</span></div>
                        <div class="siparis-iskonto">İskontolu Toplam: <span id="iskontoluTutar">0,00 ₺</span></div>
                        <button type="submit" class="btn btn-primary w-100 mt-3"><i class="fa fa-file-pdf"></i> Hesapla ve PDF Oluştur</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script>
        function formatPrice(val) {
            return Number(val).toLocaleString('tr-TR', {
                minimumFractionDigits: 2
            }) + ' ₺';
        }
        let urunler = [];
        let adetler = {};

        function urunleriYukle() {
            $.get('api-urunler.php', function(data) {
                urunler = data;
                adetler = {};
                gosterUrunler();
                hesapla();
            });
        }

        function gosterUrunler() {
            let html = '';
            urunler.forEach(u => {
                let adet = adetler[u.id] || 0;
                html += `<div class="col-md-4 col-lg-3">
            <div class="urun-kart mb-3">
                <div class="urun-isim mb-1"><i class="fa fa-battery-full me-1"></i> ${u.ad}</div>
                <div class="urun-tip mb-1">${u.tip} | <span class="text-secondary">${u.kod}</span></div>
                <div class="urun-fiyat mb-2">${formatPrice(u.satis_fiyati)} <span class="text-muted" style="font-size:.9em;">(KDV'siz: ${formatPrice(u.kdvsiz_fiyat)})</span></div>
                <div class="d-flex align-items-center justify-content-center mb-2">
                    <button type="button" class="btn btn-outline-secondary qty-btn" onclick="adetAzalt(${u.id})">-</button>
                    <input type="number" class="qty-input mx-2" min="0" name="adet[${u.id}]" value="${adet}" onchange="adetDegis(${u.id}, this.value)">
                    <button type="button" class="btn btn-outline-secondary qty-btn" onclick="adetArttir(${u.id})">+</button>
                </div>
                <div class="text-end fw-bold">Tutar: <span class="tutar">${formatPrice(u.satis_fiyati * adet)}</span></div>
            </div>
        </div>`;
            });
            $('#urunlerAlani').html(html);
        }

        function adetArttir(id) {
            adetler[id] = (adetler[id] || 0) + 1;
            gosterUrunler();
            hesapla();
        }

        function adetAzalt(id) {
            adetler[id] = Math.max(0, (adetler[id] || 0) - 1);
            gosterUrunler();
            hesapla();
        }

        function adetDegis(id, val) {
            adetler[id] = Math.max(0, parseInt(val) || 0);
            gosterUrunler();
            hesapla();
        }

        function hesapla() {
            let toplam = 0;
            urunler.forEach(u => {
                let adet = adetler[u.id] || 0;
                toplam += adet * u.satis_fiyati;
            });
            let iskonto = parseFloat($('#iskonto').val()) || 0;
            let iskontolu = toplam * (1 - iskonto / 100);
            $('#toplamTutar').text(formatPrice(toplam));
            $('#iskontoluTutar').text(formatPrice(iskontolu));
        }
        $('#iskonto').on('input', hesapla);
        $(document).on('input', '.qty-input', function() {
            let id = $(this).closest('.urun-kart').find('.urun-isim').text().trim();
            id = urunler.find(u => u.ad === id)?.id;
            adetDegis(id, this.value);
        });
        $(function() {
            urunleriYukle();
        });
    </script>
</body>

</html>