<?php
// Güvenlik: sadece pdf klasöründeki dosyalar
if (!isset($_GET['file']) || !preg_match('/^[a-zA-Z0-9_\-]+_atik_alis_\d+\.pdf$/', $_GET['file'])) {
    die('Geçersiz dosya!');
}
$pdf_file = __DIR__ . '/pdf/' . $_GET['file'];
if (!file_exists($pdf_file)) {
    die('Dosya bulunamadı!');
}
$pdf_url = 'pdfserve.php?file=' . urlencode($_GET['file']);
?>
<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <title>PDF Önizleme - Atık Akü</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f7f9fc;
            margin: 0;
        }

        .main-card {
            max-width: 900px;
            margin: 40px auto;
            background: #fff;
            border-radius: 14px;
            box-shadow: 0 8px 32px #0661aa22;
            padding: 32px;
        }

        h2 {
            color: #0661aa;
        }

        .pdf-frame {
            width: 100%;
            height: 70vh;
            border: 1px solid #eee;
            border-radius: 8px;
            margin-bottom: 18px;
        }

        .btns {
            display: flex;
            gap: 18px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .btns a {
            background: #0661aa;
            color: #fff;
            padding: 10px 24px;
            border-radius: 7px;
            font-weight: bold;
            text-decoration: none;
            box-shadow: 0 2px 8px #e3e9f7;
            transition: background 0.2s;
        }

        .btns a:hover {
            background: #2196f3;
        }

        .back-link {
            display: inline-block;
            margin-bottom: 18px;
            color: #0661aa;
            text-decoration: underline;
            font-weight: bold;
        }

        .back-link i {
            margin-right: 5px;
        }

        @media (max-width: 700px) {
            .main-card {
                padding: 8px 2px;
                max-width: 99vw;
            }

            .pdf-frame {
                height: 45vh;
            }

            .btns a {
                padding: 10px 8px;
                font-size: 0.98em;
            }
        }
    </style>
</head>

<body>
    <div class="main-card">
        <a href="index.php" class="back-link"><i class="fa-solid fa-arrow-left"></i> Ana Sayfa</a>
        <h2><i class="fa-solid fa-file-pdf" style="color:#d32f2f;margin-right:7px;"></i>PDF Önizleme</h2>
        <iframe src="<?php echo htmlspecialchars($pdf_url); ?>" class="pdf-frame" allowfullscreen></iframe>
        <div class="btns">
            <a href="<?php echo htmlspecialchars($pdf_url); ?>" download><i class="fa-solid fa-download"></i> PDF'yi İndir</a>
            <a href="<?php echo htmlspecialchars($pdf_url); ?>" target="_blank"><i class="fa-solid fa-up-right-from-square"></i> Yeni Sekmede Aç</a>
        </div>
    </div>
</body>

</html>