<?php
// Güvenlik: sadece pdf klasöründeki dosyalar
if (!isset($_GET['file']) || !preg_match('/^[a-zA-Z0-9_\-]+_atik_alis_\d+\.pdf$/', $_GET['file'])) {
    http_response_code(404);
    exit('Geçersiz dosya!');
}
$pdf_file = __DIR__ . '/pdf/' . $_GET['file'];
if (!file_exists($pdf_file)) {
    http_response_code(404);
    exit('Dosya bulunamadı!');
}
header('Content-Type: application/pdf');
header('Content-Disposition: inline; filename="' . basename($pdf_file) . '"');
header('Content-Length: ' . filesize($pdf_file));
readfile($pdf_file);
exit;
