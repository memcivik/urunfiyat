<?php
session_start();

// Basit şifre kontrolü
$admin_password = 'admin123';
if (isset($_POST['admin_password'])) {
    if ($_POST['admin_password'] === $admin_password) {
        $_SESSION['is_admin'] = true;
    } else {
        $error = 'Hatalı şifre!';
    }
}
if (isset($_GET['logout'])) {
    session_destroy();
    ob_clean();
    header('Location: index.php');
    exit;
}
if (!isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
?>
    <html>

    <head>
        <title>Yönetici Girişi</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
        <style>
            body {
                font-family: 'Roboto', Arial, sans-serif;
                background: linear-gradient(135deg, #0661aa 0%, #e3e9f7 100%);
                min-height: 100vh;
                margin: 0;
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .login-card {
                background: #fff;
                border-radius: 18px;
                box-shadow: 0 8px 32px rgba(44, 62, 80, 0.18);
                padding: 36px 28px 28px 28px;
                max-width: 350px;
                width: 96vw;
                margin: 32px auto;
                display: flex;
                flex-direction: column;
                align-items: center;
                animation: fadeIn 1s;
            }

            @keyframes fadeIn {
                from {
                    opacity: 0;
                    transform: translateY(40px);
                }

                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }

            .login-logo {
                width: 70px;
                height: 70px;
                border-radius: 50%;
                margin-bottom: 10px;
                box-shadow: 0 2px 8px rgba(44, 62, 80, 0.13);
                background: #e3e9f7;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 2.2em;
                color: #0661aa;
            }

            .login-title {
                color: #0661aa;
                font-size: 1.3em;
                font-weight: 700;
                margin-bottom: 4px;
                letter-spacing: 1px;
                text-align: center;
            }

            .login-desc {
                color: #333;
                font-size: 1em;
                margin-bottom: 18px;
                text-align: center;
            }

            .login-card form {
                width: 100%;
                display: flex;
                flex-direction: column;
                align-items: center;
            }

            .login-card input[type=password] {
                width: 100%;
                padding: 12px;
                margin-bottom: 18px;
                border-radius: 7px;
                border: 1.5px solid #bdbdbd;
                font-size: 1.1em;
                box-sizing: border-box;
                background: #f7f9fc;
                transition: border-color 0.3s, box-shadow 0.3s;
            }

            .login-card input[type=password]:focus {
                border-color: #0661aa;
                box-shadow: 0 0 0 2px #e3e9f7;
                outline: none;
            }

            .login-card button {
                padding: 12px 0;
                width: 100%;
                background: linear-gradient(90deg, #0661aa 60%, #2196f3 100%);
                color: #fff;
                border: none;
                border-radius: 8px;
                font-size: 1.1em;
                font-weight: 600;
                box-shadow: 0 4px 16px rgba(44, 62, 80, 0.10);
                transition: background 0.2s, transform 0.1s;
                cursor: pointer;
            }

            .login-card button:hover {
                background: linear-gradient(90deg, #2196f3 60%, #0661aa 100%);
                transform: translateY(-2px) scale(1.03);
            }

            .login-error {
                color: #d32f2f;
                margin-bottom: 12px;
                font-weight: bold;
                text-align: center;
            }

            @media (max-width: 500px) {
                .login-card {
                    padding: 18px 4vw 14px 4vw;
                    max-width: 99vw;
                }

                .login-title {
                    font-size: 1.1em;
                }

                .login-logo {
                    font-size: 1.5em;
                    width: 54px;
                    height: 54px;
                }
            }
        </style>
    </head>

    <body>
        <div class="login-card">
            <div class="login-logo"><i class="fa-solid fa-car-battery"></i></div>
            <div class="login-title">Atık Akü Yönetici Girişi</div>
            <div class="login-desc">Yalnızca yetkili kişiler için<br>PDF geçmiş kayıtlarına erişim</div>
            <form method="post" autocomplete="off">
                <?php if (isset($error)) echo '<div class="login-error">' . $error . '</div>'; ?>
                <input type="password" name="admin_password" placeholder="Yönetici Şifresi" required>
                <button type="submit"><i class="fa-solid fa-unlock-keyhole"></i> Giriş Yap</button>
            </form>
            <a href="index.php" class="back-home-btn" style="display:block;margin:18px auto 0 auto;background:#0661aa;color:#fff;padding:9px 0;border-radius:7px;font-weight:bold;text-align:center;text-decoration:none;max-width:220px;box-shadow:0 2px 8px #e3e9f7;">&larr; Ana Sayfaya Dön</a>
        </div>
    </body>

    </html>
<?php
    exit;
}
// PDF dosyalarını listele
$pdf_dir = __DIR__ . '/pdf';
$pdf_files = [];
if (is_dir($pdf_dir)) {
    foreach (glob($pdf_dir . '/*.pdf') as $file) {
        $pdf_files[] = [
            'name' => basename($file),
            'time' => filemtime($file),
            'url' => 'pdf/' . basename($file)
        ];
    }
    usort($pdf_files, function ($a, $b) {
        return $b['time'] - $a['time'];
    });
}
// Silme işlemi
if (isset($_GET['delete']) && isset($_SESSION['is_admin']) && $_SESSION['is_admin']) {
    $del_file = basename($_GET['delete']);
    $del_path = $pdf_dir . '/' . $del_file;
    if (file_exists($del_path)) {
        unlink($del_path);
        header('Location: admin.php?deleted=1');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <title>Yönetici Paneli</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f7f9fc;
        }

        .panel {
            max-width: 900px;
            margin: 40px auto;
            background: #fff;
            border-radius: 14px;
            box-shadow: 0 8px 32px #0661aa22;
            padding: 32px;
        }

        h2 {
            color: #0661aa;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 18px;
        }

        th,
        td {
            padding: 12px;
            border: 1px solid #e3e6ed;
            text-align: center;
        }

        th {
            background: linear-gradient(90deg, #0661aa 60%, #2196f3 100%);
            color: #fff;
        }

        tr:hover {
            background: #f0f4fa;
        }

        .btn-del {
            background: #d32f2f;
            color: #fff;
            border: none;
            border-radius: 6px;
            padding: 7px 18px;
            font-weight: bold;
            cursor: pointer;
        }

        .btn-del:hover {
            background: #b71c1c;
        }

        .logout {
            float: right;
            color: #0661aa;
            text-decoration: underline;
            font-size: 1em;
        }

        .msg {
            color: #388e3c;
            margin-bottom: 12px;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <div class="panel">
        <a href="?logout=1" class="logout">Çıkış Yap</a>
        <h2>Yönetici Paneli</h2>
        <?php if (isset($_GET['deleted'])) echo '<div class="msg">Dosya silindi.</div>'; ?>
        <table>
            <tr>
                <th>Dosya Adı</th>
                <th>Tarih</th>
                <th>İşlem</th>
            </tr>
            <?php foreach ($pdf_files as $pdf): ?>
                <tr>
                    <td><?php echo htmlspecialchars($pdf['name']); ?></td>
                    <td><?php echo date('d.m.Y H:i', $pdf['time']); ?></td>
                    <td>
                        <a href="<?php echo $pdf['url']; ?>" target="_blank" style="margin-right:8px;">Görüntüle</a>
                        <a href="?delete=<?php echo urlencode($pdf['name']); ?>" onclick="return confirm('Silmek istediğinize emin misiniz?')" class="btn-del">Sil</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
</body>

</html>