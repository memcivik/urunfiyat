self.addEventListener('install', function(e) {
  e.waitUntil(
    caches.open('atikaku-cache').then(function(cache) {
      return cache.addAll([
        '/',
        '/index.php',
        '/css/style.css',
        '/image/favicon.jpg'
        // Diğer önemli dosyaları ekleyebilirsin
      ]);
    })
  );
});

self.addEventListener('fetch', function(e) {
  e.respondWith(
    caches.match(e.request).then(function(response) {
      return response || fetch(e.request);
    })
  );
}); 